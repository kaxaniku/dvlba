// 1.
var a = "kaxa";
var b = "niku";
var c = "14";
console.log("1." + a + b + c);
// 2.
a = 1000;
b = 100;
c = a-b;
if (c<a) {
    console.log("2." + c);
} else {
    console.log("2." + a);
}
// 3.
a = 14;
b = 2;
c = a%2;
if (c==0) {
    console.log("3.iyofa unashtod");
} else {
    console.log("3.nashtiania" + c);
}
// 4.
a = "kaxa";
if (a.indexOf("a") > 0){
    console.log("4."+a.indexOf("a"));
} else {
    console.log("4.ar arsebobs");
}
// 5.
a = "kaxa niku 14 wlisaa";
b = a.length;
if(b < 5) {
    console.log("5."+a.slice(4));
} else if (b>5 && 15>b){
    console.log("5."+a.slice(6,11));
} else if(b > 15) {
    console.log("5."+a.slice(b-5));
}
// 6.
a = "this is a classroom";
console.log("6." + a.substr(3,5));
// 7.
a ="My name is x";
console.log("7." + a.replace("x","kaxa"))
// 8.
a = "kaxa niku";
a =a.toUpperCase();
console.log("8."  +a);
a =a.toLowerCase()
console.log("8." + a);
// 9.
a = "banana,apple,kiwi";
console.log("9." + a);